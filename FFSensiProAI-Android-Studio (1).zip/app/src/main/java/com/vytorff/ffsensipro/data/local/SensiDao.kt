package com.vytorff.ffsensipro.data.local

import androidx.room.*
import com.vytorff.ffsensipro.data.model.SensiConfig
import kotlinx.coroutines.flow.Flow

@Dao
interface SensiDao {
    @Query("SELECT * FROM sensi_table ORDER BY timestamp DESC LIMIT 10")
    fun getHistory(): Flow<List<SensiConfig>>

    @Query("SELECT * FROM sensi_table WHERE isFavorite = 1 ORDER BY timestamp DESC LIMIT 20")
    fun getFavorites(): Flow<List<SensiConfig>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(sensi: SensiConfig): Long

    @Query("SELECT * FROM sensi_table WHERE device = :device AND style = :style AND isFavorite = 1 LIMIT 1")
    suspend fun findFavorite(device: String, style: String): SensiConfig?

    @Query("DELETE FROM sensi_table WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM sensi_table WHERE id NOT IN (SELECT id FROM sensi_table ORDER BY timestamp DESC LIMIT 10) AND isFavorite = 0")
    suspend fun trimHistory()

    @Query("DELETE FROM sensi_table WHERE id NOT IN (SELECT id FROM sensi_table WHERE isFavorite = 1 ORDER BY timestamp DESC LIMIT 20) AND isFavorite = 1")
    suspend fun trimFavorites()
}