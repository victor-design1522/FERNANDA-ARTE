package com.vytorff.ffsensipro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.vytorff.ffsensipro.ui.components.AdMobInterstitialHelper
import com.vytorff.ffsensipro.ui.screens.MainScreen
import com.vytorff.ffsensipro.ui.theme.FFSensiProAITheme
import com.vytorff.ffsensipro.ui.viewmodel.SensiViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: SensiViewModel by viewModels()
    private lateinit var interstitialHelper: AdMobInterstitialHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        interstitialHelper = AdMobInterstitialHelper(this)

        setContent {
            FFSensiProAITheme {
                MainScreen(
                    viewModel = viewModel,
                    interstitialHelper = interstitialHelper
                )
            }
        }
    }
}