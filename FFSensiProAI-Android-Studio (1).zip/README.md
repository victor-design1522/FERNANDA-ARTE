# FF SENSI PRO AI - PROJETO ANDROID COMPLETO
Desenvolvido por VYTOR FF

## 1. ONDE COLOCAR SEUS IDS DO GOOGLE ADMOB:
Abra o arquivo: app/src/main/java/com/vytorff/ffsensipro/AdMobConfig.kt
Substitua os IDs pelos seus próprios:
- ADMOB_APP_ID
- ADMOB_BANNER_ID
- ADMOB_INTERSTITIAL_ID

## 2. GERAR APK (Instalação Direta):
No Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s)

## 3. GERAR AAB (Publicação na Google Play):
No Android Studio: Build > Generate Signed Bundle / APK > Android App Bundle