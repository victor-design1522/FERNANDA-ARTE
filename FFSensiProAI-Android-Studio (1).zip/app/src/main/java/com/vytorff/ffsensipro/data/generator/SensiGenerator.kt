package com.vytorff.ffsensipro.data.generator

import com.vytorff.ffsensipro.data.model.SensiConfig
import kotlin.math.abs

object SensiGenerator {

    fun hashStr(str: String): Long {
        var hash = 0
        for (i in 0 until str.length) {
            val charCode = str[i].code
            hash = charCode + ((hash shl 5) - hash)
        }
        return abs(hash.toLong())
    }

    fun generate(deviceInput: String, style: String, fingers: String): SensiConfig {
        val trimmedDevice = deviceInput.trim().ifEmpty { "Aparelho Personalizado" }
        val seed = hashStr(trimmedDevice.lowercase() + style)

        var baseDpi: Long
        var baseGeral: Long
        var baseRedDot: Long
        var base2x: Long
        var base4x: Long
        var baseAwm: Long

        var baseBtn = 40L + (seed % 25)
        if (fingers == "2") baseBtn += 5
        if (fingers == "4" || fingers == "5") baseBtn -= 5

        when (style) {
            "Capa" -> {
                baseDpi = 600 + (seed % 300)
                baseGeral = 90 + (seed % 10)
                baseRedDot = 85 + (seed % 15)
                base2x = 90 + (seed % 10)
                base4x = 90 + (seed % 10)
                baseAwm = 30 + (seed % 20)
            }
            "Rush" -> {
                baseDpi = 500 + (seed % 250)
                baseGeral = 100
                baseRedDot = 95 + (seed % 5)
                base2x = 100
                base4x = 95 + (seed % 5)
                baseAwm = 50 + (seed % 20)
            }
            "X1" -> {
                baseDpi = 700 + (seed % 260)
                baseGeral = 100
                baseRedDot = 100
                base2x = 100
                base4x = 100
                baseAwm = 40 + (seed % 20)
            }
            "Precisão" -> {
                baseDpi = 411 + (seed % 200)
                baseGeral = 80 + (seed % 15)
                baseRedDot = 75 + (seed % 15)
                base2x = 80 + (seed % 15)
                base4x = 80 + (seed % 15)
                baseAwm = 20 + (seed % 20)
            }
            "Sniper" -> {
                baseDpi = 450 + (seed % 150)
                baseGeral = 85 + (seed % 10)
                baseRedDot = 80 + (seed % 10)
                base2x = 80 + (seed % 15)
                base4x = 75 + (seed % 15)
                baseAwm = 10 + (seed % 25)
            }
            else -> {
                baseDpi = 600
                baseGeral = 95
                baseRedDot = 90
                base2x = 90
                base4x = 90
                baseAwm = 30
            }
        }

        val baseLook = 50 + (seed % 50)
        val isApple = trimmedDevice.lowercase().contains("iphone") || trimmedDevice.lowercase().contains("ipad")
        val dpiDisplay = if (isApple) "Padrão (S/ DPI)" else baseDpi.toString()

        return SensiConfig(
            device = trimmedDevice,
            style = style,
            fingers = fingers,
            dpi = dpiDisplay,
            geral = baseGeral.toInt(),
            redDot = baseRedDot.toInt(),
            m2x = base2x.toInt(),
            m4x = base4x.toInt(),
            awm = baseAwm.toInt(),
            look = baseLook.toInt(),
            fireBtn = baseBtn.toInt()
        )
    }
}