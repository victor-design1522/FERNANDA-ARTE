package com.vytorff.ffsensipro

/**
 * =========================================================================================
 *                          CONFIGURAÇÃO CENTRALIZADA DO GOOGLE ADMOB
 * =========================================================================================
 *
 * Aqui você define os IDs do Google AdMob para o aplicativo FF SENSI PRO AI.
 * Durante o desenvolvimento, o app utiliza os IDs OFICIAIS DE TESTE do Google para evitar
 * qualquer tipo de suspensão ou banimento de conta.
 *
 * QUANDO FOR PUBLICAR O APLICATIVO NA GOOGLE PLAY:
 * 1. Substitua os IDs de teste abaixo pelos seus próprios IDs criados no console do AdMob.
 * 2. Lembre-se de atualizar também o ID no arquivo AndroidManifest.xml caso necessário.
 * =========================================================================================
 */
object AdMobConfig {

    /**
     * ID DO APLICATIVO ADMOB (App ID)
     * Formato: ca-app-pub-XXXXXXXXXXXXXXXX~YYYYYYYYYY
     *
     * SUBSTITUA PELO SEU ADMOB APP ID
     */
    const val ADMOB_APP_ID: String = "ca-app-pub-3940256099942544~3347511713"

    /**
     * ID DO BLOCO DE ANÚNCIO DE BANNER (Banner Ad Unit ID)
     * Formato: ca-app-pub-XXXXXXXXXXXXXXXX/YYYYYYYYYY
     *
     * SUBSTITUA PELO SEU ADMOB BANNER ID
     */
    const val ADMOB_BANNER_ID: String = "ca-app-pub-3940256099942544/6300978111"

    /**
     * ID DO BLOCO DE ANÚNCIO INTERSTICIAL (Interstitial Ad Unit ID)
     * Formato: ca-app-pub-XXXXXXXXXXXXXXXX/YYYYYYYYYY
     *
     * SUBSTITUA PELO SEU ADMOB INTERSTITIAL ID
     */
    const val ADMOB_INTERSTITIAL_ID: String = "ca-app-pub-3940256099942544/1033173712"

    /**
     * Frequência do Intersticial: a cada quantas gerações de sensibilidade exibir o anúncio.
     * Padrão recomendado: 2 gerações para não incomodar o usuário.
     */
    const val INTERSTITIAL_GENERATION_INTERVAL: Int = 2
}