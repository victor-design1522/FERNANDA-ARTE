package com.vytorff.ffsensipro.ui.components

import android.app.Activity
import android.content.Context
import com.google.android.gms.ads.*
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.vytorff.ffsensipro.AdMobConfig

class AdMobInterstitialHelper(private val context: Context) {
    private var interstitialAd: InterstitialAd? = null
    private var isLoading = false
    private var generationCount = 0

    init {
        loadAd()
    }

    fun loadAd() {
        if (isLoading || interstitialAd != null) return
        isLoading = true
        InterstitialAd.load(
            context,
            AdMobConfig.ADMOB_INTERSTITIAL_ID,
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                    isLoading = false
                }
                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    interstitialAd = null
                    isLoading = false
                }
            }
        )
    }

    fun checkAndShowOnGeneration(activity: Activity, onDismissed: () -> Unit = {}) {
        generationCount++
        if (generationCount % AdMobConfig.INTERSTITIAL_GENERATION_INTERVAL == 0) {
            interstitialAd?.let { ad ->
                ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                    override fun onAdDismissedFullScreenContent() {
                        interstitialAd = null
                        loadAd()
                        onDismissed()
                    }
                }
                ad.show(activity)
            } ?: run {
                loadAd()
                onDismissed()
            }
        } else {
            onDismissed()
        }
    }
}